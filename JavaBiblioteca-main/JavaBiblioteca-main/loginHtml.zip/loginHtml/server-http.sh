#!/bin/bash
#
#
npx http-server ./ -p 3001 --cors

#
#
